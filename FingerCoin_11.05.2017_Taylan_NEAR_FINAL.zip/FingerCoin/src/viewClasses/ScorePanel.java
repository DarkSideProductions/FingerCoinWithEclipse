package viewClasses;
import playground.*;
import controllerClasses.*;
import java.util.*;
import java.awt.*;
import java.awt.event.*;
import java.awt.image.BufferedImage;
import java.io.BufferedReader;
import java.io.File;
import java.io.FileReader;
import java.io.IOException;

import javax.imageio.ImageIO;
import javax.swing.*;
/**
 * @author TAYLAN
 *
 */
public class ScorePanel extends JPanel 
{
	//properties
	private JLabel chances;
	private JLabel p1,  p2;
	private int trycount, try1, try2;
	private String name1, name2;
	private JButton gameMenu;
	private GamePanel gamePanel;
	private int numOfPlayers;
	private FileReader fr = null;
	private BufferedReader br = null;
	private BufferedImage background;
	

	//constructors
	public ScorePanel(GamePanel gp)
	{
		this.gamePanel = gp;
		gameMenu = new JButton("GAME MENU");
		setLayout(null);
		gameMenu.setBounds(240, 15, 120, 30);
		setPreferredSize(new Dimension(600, 60));
		trycount = gamePanel.getField().getScore();
		numOfPlayers = 1;
		try
		{
			background = ImageIO.read(new File("gameGround.jpg"));
		}
		catch(IOException e){}
		chances = new JLabel("You Tried: " + trycount);
		chances.setBounds(30, 15, 150, 30);
		chances.setText("You Tried: " + trycount);
		chances.setForeground(Color.YELLOW);
		chances.setFont(new Font("Arial", 1, 14));
		add(gameMenu);
		add(chances);
	}
	public ScorePanel(GamePanel gp, String name1,String name2)
	{
		this.gamePanel = gp;
		gameMenu = new JButton("GAME MENU");
		setLayout(null);
		gameMenu.setBounds(240, 15, 120, 30);
		this.name1 = name1;
		this.name2 = name2;
		numOfPlayers = 2;
		try
		{
			background = ImageIO.read(new File("gameGround.jpg"));
		}
		catch(IOException e){}
		setPreferredSize(new Dimension(600, 60));
		initPanel(name1, name2);
	}
	public void initPanel(String name1, String name2)
	{
		this.name1 = name1;
		this.name2 = name2;
		try1 = 0;
		try2 = 0;
		p1 = new JLabel(name1 +  ": " + try1 + " Tries");
		p2 = new JLabel(name2 +": " + try2 + " Tries");
		p1.setBounds(30, 15, 150, 30);
		p2.setBounds(450, 15, 150, 30);
		p1.setFont(new Font("Arial", 1, 14));
		p2.setFont(new Font("Arial", 1, 14));
		p1.setForeground(Color.YELLOW);
		p2.setForeground(Color.YELLOW);
		add(gameMenu);
		add(p1);
		add(p2);
	}
	
	/**
	 * Gets the name of the first player.
	 * @return the name of the first player.
	 */
	public String getName1()
	{
		return name1;
	}
	/**
	 * Gets the name of the second player.
	 * @return the name of the second player.
	 */
	public String getName2()
	{
		return name2;
	}
	/**
	 * Sets the name of the players..
	 * @param nm1 the name of the first player.
	 * @param nm2 the name of the second player.
	 */
	public void setNames(String nm1, String nm2)
	{
		name1 = nm1;
		name2 = nm2;
		initPanel(name1, name2);
	}
	//methods
	/**
	 * Paints the scoreboard.
	 * @param g the Graphics object.
	 */
	public void paintComponent(Graphics g)
	{
		if(numOfPlayers == 1)
		{
			chances.setText("Chances Left: " + trycount + " Tries");
		}

		if(numOfPlayers == 2)
		{
			try {
				fr = new FileReader("name1.txt");
				br = new BufferedReader(fr);
				name1 = br.readLine();
				br.close();
			} catch (IOException a) {
				a.printStackTrace();
			}
			try {
				fr = new FileReader("name2.txt");
				br = new BufferedReader(fr);
				name2 = br.readLine();
				br.close();
			} catch (IOException a) {
				a.printStackTrace();
			}
			p1.setText(name1 + ": " + try1 + " Tries");
			p2.setText(name2 + ": " + try2 + " Tries");
		}
		super.paintComponent(g);
		g.drawRect(0, 0, 800, 120);
		g.drawImage(background, 0, 0, this);
	}
	/**
	 * Returns the button(s) in this panel.
	 * @return the game menu button.
	 */
	public JButton getButton()
	{
		return gameMenu;
	}
	/**
	 * Sets the tries of the player.
	 * @param tries the set tries.
	 */
	public void setTries(int tries)
	{
		trycount = tries;
	}
	/**
	 * Sets the tries of the player.
	 * @param tries the set tries.
	 */
	public void setTriesP1(int tries)
	{
		try1 = tries;
	}
	/**
	 * Sets the tries of the player.
	 * @param tries the set tries.
	 */
	public void setTriesP2(int tries)
	{
		try2 = tries;
	}
	/**
	 * Returns the current player.
	 * @return the current player.
	 */
	public int getPlayerNum() 
	{
		return numOfPlayers;
	}

}
