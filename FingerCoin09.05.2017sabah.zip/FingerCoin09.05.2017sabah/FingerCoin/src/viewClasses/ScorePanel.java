package viewClasses;
import playground.*;
import controllerClasses.*;
import java.util.*;
import java.awt.*;
import java.awt.event.*;
import javax.swing.*;
/**
 * This class is the score panel of the FingerCoin game.
 * @author S�leyman Taylan Topalo�lu
 * @version 09.05.2017
 */
public class ScorePanel extends JPanel {
	
	//properties
		private JLabel chances;
		private JLabel p1,  p2;
		private int trycount, try1, try2;
		private JButton gameMenu;
		private GeneralListener cl;
		private GamePanel gamePanel;
		private int numOfPlayers;
		
		//constructors
		public ScorePanel(GamePanel gp, int playerNum) {
			this.gamePanel = gp;
			gameMenu = new JButton("GAME MENU");
			cl = new GeneralListener();
			gameMenu.addActionListener(cl);
			setLayout(null);
			gameMenu.setBounds(240, 30, 120, 30);
			numOfPlayers = playerNum;
			
			if(playerNum == 1) {
				trycount = gamePanel.getField().getScore();
				chances = new JLabel("Chances Left: " + trycount + " Tries");
				chances.setBounds(30, 30, 150, 30);
				chances.setText("You Tried " + trycount);
				add(gameMenu);
				add(chances);
			}
			else if(playerNum == 2) {
				try1 = 0;
				try2 = 0;
				p1 = new JLabel("First Player: " + try1 + " Tries");
				p2 = new JLabel("Second Player: " + try2 + " Tries");
				p1.setBounds(30, 30, 150, 30);
				p2.setBounds(450, 30, 150, 30);
				add(gameMenu);
				add(p1);
				add(p2);
			}
			setPreferredSize(new Dimension(600, 60));
		}
		
		//methods
		/**
		 * Paints the scoreboard.
		 * @param g the Graphics object.
		 */
		public void paintComponent(Graphics g) {
			super.paintComponent(g);
			g.drawRect(0, 0, 800, 120);
		}
		
		public void setTries(int tries) {
			trycount = tries;
		}
		
		public void setTriesP1(int tries) {
			try1 = tries;
		}
		
		public void setTriesP2(int tries) {
			try2 = tries;
		}
		
		public int getPlayerNum() {
			return numOfPlayers;
		}
}
