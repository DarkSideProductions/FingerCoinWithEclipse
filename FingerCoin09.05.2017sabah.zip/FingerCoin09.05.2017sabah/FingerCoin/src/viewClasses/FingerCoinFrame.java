package viewClasses;
import playground.*;
import controllerClasses.*;
import java.awt.*;
import java.awt.event.*;
import java.awt.image.*;
import javax.swing.*;
import javax.swing.event.*;
import javax.imageio.*;
import java.io.*;
/**
 * The total FingerCoinFrame!!
 * @author S�leyman Taylan Topalo�lu, Mustafa Bay
 * @version 07.05.2017
 */
public class FingerCoinFrame extends JFrame {
	
	//properties
	private static JPanel cards;
	private MainMenuPanel mainMenu;
	private SettingsPanel settings;
	private NameSelectionPanel nameSelect;
	private CreditsPanel credits;
	private InfoPanel info;
	private PauseMenuPanel pauseMenu;
	private static CardLayout cardL;
	private BufferedImage background;
	private static GamePanel spGame, mpGame;
	private PlayPanel spPlay, mpPlay;
	private GameSound gS;
	private int difficultyLevel;
	private int coinType;
	private ScorePanel scoreP;
	private String sCurrentLine;
	private BufferedReader br = null;
	private FileReader fr = null;
	private String sCurrentLines;
	private BufferedReader br1 = null;
	private FileReader fr1 = null;
	
	//constructor
	public FingerCoinFrame() {
		setSize(800, 1080);
		initComponents();
	}
	
	//methods
	/**
	 * Sets up the components for FingerCoin.
	 */
	public void initComponents() {
		mainMenu = new MainMenuPanel();
		mainMenu.setName("main menu");
		settings = new SettingsPanel();
		settings.setName("settings");
		nameSelect = new NameSelectionPanel();
		nameSelect.setName("name selection");
		credits = new CreditsPanel();
		info = new InfoPanel();
		pauseMenu = new PauseMenuPanel();
		difficultyLevel = settings.getDifficulty();
		coinType = settings.getCoinType();
		
		try {
			fr = new FileReader("difficulty.txt");
			br = new BufferedReader(fr);
			sCurrentLine = br.readLine();
			br = new BufferedReader(new FileReader("difficulty.txt"));
			br.close();
			fr.close();
		} 
		catch (IOException e) {
			e.printStackTrace();
		}
		
		try {
            fr1 = new FileReader("coinType.txt");
			br1 = new BufferedReader(fr1);
			sCurrentLines = br1.readLine();
			br1 = new BufferedReader(new FileReader("coinType.txt"));
			br1.close();
			fr1.close();
			} 
		catch (IOException e) {
				e.printStackTrace();
		}
		
		spGame = new GamePanel(Integer.parseInt(sCurrentLine), 1, Integer.parseInt(sCurrentLines));
		mpGame = new GamePanel(Integer.parseInt(sCurrentLine), 2, Integer.parseInt(sCurrentLines));
		spPlay = new PlayPanel(spGame, 1);
		spPlay.setName( "spPlay");
		mpPlay = new PlayPanel(mpGame, 2);
		mpPlay.setName( "mpPlay");
		gS = new GameSound("Pokemon.mp3");
		gS.changeSound(settings.getSoundLevel());
		
		try {
			background = ImageIO.read(new File("table.jpg"));
		}
		catch(IOException e){}
		
		cards = new JPanel(new CardLayout());
		cards.add(mainMenu, "main menu");
		cards.add(settings, "settings");
		cards.add(nameSelect, "name selection");
		cards.add(info, "info");
		cards.add(credits, "credits");
		cards.add(spPlay, "single player game");
		cards.add(mpPlay, "multi player game");
		cards.add(pauseMenu, "pause");
		
		for(JButton s: settings.getAllDifficultyButtons()) {
			s.addActionListener(new DiffCoinListener());
		}
		cardL = (CardLayout) cards.getLayout();
		cardL.show(cards, "main menu");
		add(cards);
	}
	
	class DiffCoinListener implements ActionListener {
		public void actionPerformed(ActionEvent e) {
			if(settings.getPressedButton(e).getText().equals("Easy")) {
				System.out.println(settings.getDifficulty());
			}
			if(settings.getPressedButton(e).getText().equals("Medium")) {
				System.out.println(settings.getDifficulty());
				difficultyLevel = settings.getDifficulty();
			}
			if(settings.getPressedButton(e).getText().equals("Hard")) {
				System.out.println(settings.getDifficulty());
				difficultyLevel = settings.getDifficulty();
			}
			if(settings.getPressedButton(e).getText().equals("LECTURE")) {
				System.out.println(settings.getDifficulty());
				difficultyLevel = settings.getDifficulty();
			}
		}
	}
	
	/**
	 * Changes the current panel.
	 * @param str the String parameter that invokes the panels' names.
	 */
	public static void changePanel(String str) {
		if ( !(str.equals( "game") || str.equals( "main menu"))) {
			cardL.show( cards, str);
		}
		else if ( str.equals( "main menu")) {
			cardL.show( cards, str);
			//??? 
		}
		else if ( spGame.isActive()) {
			spGame.loadTimer();
			cardL.show( cards, "spPlay");
		}
		else {
			mpGame.loadTimer();
			cardL.show( cards, "mpPlay");
		}
		
		if ( str.equals("pause")) {
			if ( spGame.isActive()) {
				spGame.pauseTimer();	
			}
			else {
				mpGame.pauseTimer();
			}
			cardL.show( cards, str);
		}
	}

	/**
	 * Starts the program.
	 */
	public static void main(String[] args) {
		FingerCoinFrame fr = new FingerCoinFrame();
		fr.setVisible(true);
		fr.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
	}
}
