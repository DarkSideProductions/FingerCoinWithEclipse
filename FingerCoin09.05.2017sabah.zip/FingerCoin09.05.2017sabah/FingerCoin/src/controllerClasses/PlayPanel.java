package controllerClasses;
import javax.swing.*;
import viewClasses.*;
import playground.*;
import java.awt.*;
import java.awt.event.*;
import java.awt.*;
import java.awt.image.*;
import javax.imageio.*;
import java.io.*;
import java.util.ArrayList;
/**
 * This class is the total playing panel of FingerCoin.
 * @author Mustafa Bay, S�leyman Taylan Topalo�lu
 * 08.05.2017
 */
public class PlayPanel extends JPanel {
	
	//properties
	private GamePanel gamePanel;
	private GameListener2 gl;
	private int leftTries, numOfTries;
	private Timer timer;
	private int playerNumber;
	private ScorePanel scoreP;
	
	/**
	 * Constructor
	 * @param gamePanel is the current game panel.
	 * @param numOfPlayers is the number of players.
	 */
	public PlayPanel(GamePanel gamePanel , int numOfPlayers) {
		this.gamePanel = gamePanel;
		setPreferredSize(new Dimension(800, 1080));
		setLayout(null);
		gl = new GameListener2();
		this.timer = new Timer( 10, gl);
		timer.start();
		playerNumber = numOfPlayers;
		scoreP = new ScorePanel( this.gamePanel, playerNumber);
		scoreP.setBounds( 0, 0, 600, 60);
		this.gamePanel.setBounds( 0, 60, 600, 700);
		this.gamePanel.returnDirection().setBounds( 400, 850, 200, 200);
		this.gamePanel.returnPower().setBounds(0, 800, 300, 200);
		add( scoreP);
		add( this.gamePanel);
		add( this.gamePanel.returnDirection());
		add( this.gamePanel.returnPower());
	}
	
	/**
	 * This class updates how many tries players have used.
	 */
	class GameListener2 implements ActionListener {
		
		public void actionPerformed( ActionEvent e) {
			if( playerNumber == 1) {
				scoreP.setTries(gamePanel.getField().getScore());
			}
			else {
				/*if(!gamePanel.isPlayer1sTurn())
				{
					gamePanel.reset();
					//gamePanel.repaint();
				}*/
				
			}
			repaint();	
		}
    }
	
	/**
	 * Gets the number of players
	 * @return playerNumber
	 */
	public int getNumOfPlayers() {
		return playerNumber;
	}
	
	/**
	 * For testing.
	 */
	public static void main(String[] args) {
		JFrame fr = new JFrame();
		fr.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		GamePanel x = new GamePanel( 0, 2, 1);
		PlayPanel pp = new PlayPanel(x, 2);
		fr.setSize(800, 1080);
		fr.add(pp);
		fr.setVisible(true);
	}
}
