package controllerClasses;
import java.awt.FlowLayout;

import java.awt.event.ActionEvent;

import java.awt.event.ActionListener;

import javax.swing.*;

/** This Class demonstrates an example of customized non-modal JDialog with two default JButtons

* and the default work flow to next customized Dialog
*/

public class MyDialog extends JDialog {

	// default attributes of customized JDialog
	// you can set every GUI components you like just as the JFrame :)

	private JButton okButton = new JButton("OK");
	private JButton cancelButton = new JButton("Cancel");
	private MyDialog nextDialog;

	// this constructor only accept one parameter,
	// you can change it to what you like for better customization :)
	public MyDialog(final MyDialog nextDialog) {
		super();
		setDefaultCloseOperation(JDialog.DISPOSE_ON_CLOSE);
		setModal(false);

		//the dialog to be display when this dialog is closed
		this.nextDialog = nextDialog;

		//configure the layout of this dialog
		setLayout(new FlowLayout());
		add(okButton);
		add(cancelButton);
		pack();

		//register listener for the two defaults buttons
		okButton.addActionListener(new ActionListener() {

			@Override
			public void actionPerformed(ActionEvent arg0) {
				// show the next dialog only when it is exist
				if (nextDialog != null)
					nextDialog.setVisible(true);
				setVisible(false); //  or dispose() if you want to destroy this dialog in the memory
			}
		});

		cancelButton.addActionListener(new ActionListener() {

			@Override
			public void actionPerformed(ActionEvent arg0) {
				dispose();
			}
		});
	}
}