/**
 * 
 */
package viewClasses;

import javax.swing.JFrame;

/**
 * @author TAYLAN
 *
 */
public class GameFrameTest extends JFrame {

}
