package viewClasses;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import javax.swing.JButton;

/**
 * A general ActionListener for FingerCoin.
 * @author Süleyman Taylan Topaloğlu
 * @version 07.05.2017
 */
public class GeneralListener implements ActionListener 
{
	/**
	 * Processes the action event.
	 * @param e the action event.
	 */
	public void actionPerformed(ActionEvent e) 
	{
		
		if(((JButton)e.getSource()).getText().equals("Back to main menu"))
		{
			FingerCoinFrame.changePanel("main menu");
		}
		else if(((JButton)e.getSource()).getText().equals("Close"))
		{
			FingerCoinFrame.changePanel("settings");
		}
		else if(((JButton)e.getSource()).getText().equals("Back to settings"))
		{
			FingerCoinFrame.changePanel("settings");
		}
		else if(((JButton)e.getSource()).getText().equals("CREDITS"))
		{
			FingerCoinFrame.changePanel("credits");
		}
		else if(((JButton)e.getSource()).getText().equals("RULES"))
		{
			FingerCoinFrame.changePanel("info");
		}
		else if(((JButton)e.getSource()).getText().equals("Settings"))
		{
			FingerCoinFrame.changePanel("settings");
		}
		else if(((JButton)e.getSource()).getText().equals("Single Player"))
		{
			FingerCoinFrame.changePanel("single player game");
		}
		else if(((JButton)e.getSource()).getText().equals("Multi Player"))
		{
			FingerCoinFrame.changePanel("name selection");
		}
		else if(((JButton)e.getSource()).getText().equals("CLICK TO CONTINUE"))
		{
			FingerCoinFrame.changePanel("multi player game");
		}
		else if(((JButton)e.getSource()).getText().equals("GAME MENU"))
		{
			FingerCoinFrame.changePanel("pause");
		}
		else if(((JButton)e.getSource()).getText().equals("FORFEIT GAME"))
		{
			FingerCoinFrame.changePanel("main menu");
		}
		else if(((JButton)e.getSource()).getText().equals("INFO"))
		{
			FingerCoinFrame.changePanel("info");
		}
		else if(((JButton)e.getSource()).getText().equals("RESUME GAME"))
		{
			
		}
		else if(((JButton)e.getSource()).getText().equals("Exit"))
		{
			System.exit(0);
		}
	}
}
