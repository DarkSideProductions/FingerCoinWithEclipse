package viewClasses;
import playground.*;
import controllerClasses.*;
import java.awt.*;
import java.awt.event.*;
import javax.swing.*;
import javax.swing.event.*;
/**
 * The total FingerCoinFrame!!
 * @author Süleyman Taylan Topaloğlu
 * @version 07.05.2017
 */
public class FingerCoinFrame extends JFrame
{
	//properties
	private JPanel cards;
	private MainMenuPanel mainMenu;
	private SettingsPanel settings;
	private NameSelectionPanel nameSelect;
	private CreditsPanel credits;
	private InfoPanel info;
	private PauseMenuPanel pauseMenu;
	private CardLayout cardL;
	private GamePanel spGame, mpGame;
	private PlayPanel spPlay, mpPlay;
	private GameSound gS;
	private int difficultyLevel;
	private int coinType;
	private String name1, name2;
	private Timer timer;
	
	//constructor
	public FingerCoinFrame()
	{
		mainMenu = new MainMenuPanel();
		settings = new SettingsPanel();
		nameSelect = new NameSelectionPanel();
		credits = new CreditsPanel();
		info = new InfoPanel();
		pauseMenu = new PauseMenuPanel();
		spGame = new GamePanel(difficultyLevel, 1, coinType);
		mpGame = new GamePanel(difficultyLevel, 2, coinType);
		spPlay = new PlayPanel(spGame);
		mpPlay = new PlayPanel(mpGame, name1, name2);
		gS = new GameSound("menu.mp3");
		
		//sizing
		setSize(800, 1080);
		timer = new Timer(5, new ReturnMainListener());
		timer.start();
		initComponents();
	}
	
	//methods
	/**
	 * Sets up the components for FingerCoin.
	 */
	public void initComponents()
	{
		settings.getSoundSlider().addChangeListener(new SoundChangeListener());
		gS.changeSound(settings.getSoundSlider().getValue() / 100.0);
		gS.start();
		
		//adding the panels
		cards = new JPanel(new CardLayout());
		cards.add(mainMenu, "main menu");
		cards.add(settings, "settings");
		cards.add(nameSelect, "name selection");
		cards.add(info, "info");
		cards.add(credits, "credits");
		cards.add(spPlay, "single player game");
		cards.add(mpPlay, "multi player game");
		cards.add(pauseMenu, "pause");
		
		//adding the necessary listeners
		for(JButton s: settings.getButtons())
		{
			s.addActionListener(new MenuChangeListener());
		}

		for(JButton s: mainMenu.getButtons())
		{
			s.addActionListener(new MenuChangeListener());
		}
		
		info.getButton().addActionListener(new MenuChangeListener());
		credits.getButton().addActionListener(new MenuChangeListener());
		spPlay.getScorePanel().getButton().addActionListener(new MenuChangeListener());
		mpPlay.getScorePanel().getButton().addActionListener(new MenuChangeListener());
		for(JButton s: pauseMenu.getButtons())
		{
			s.addActionListener(new MenuChangeListener());
		}
		
		for(JButton s: nameSelect.getButtons())
		{
			s.addActionListener(new MenuChangeListener());
		}
		
		//setting the card layout
		cardL = (CardLayout) cards.getLayout();
		cardL.show(cards, "main menu");
		add(cards);
	}
	
	class MenuChangeListener implements ActionListener 
	{
		/**
		 * Processes the action event.
		 * @param e the action event.
		 */
		public void actionPerformed(ActionEvent e) 
		{
			//changing menus
			if(((JButton)e.getSource()).getText().equals("Back to main menu"))
			{
				changePanel("main menu");
			}
			else if(((JButton)e.getSource()).getText().equals("Close"))
			{
				if(spGame.isActive())
				{
					changePanel("pause");
				}
				else if(mpGame.isActive())
				{
					changePanel("pause");
				}
				else
				{
					changePanel("settings");
				}
			}
			else if(((JButton)e.getSource()).getText().equals("Back to settings"))
			{
				changePanel("settings");
			}
			else if(((JButton)e.getSource()).getText().equals("CREDITS"))
			{
				changePanel("credits");
			}
			else if(((JButton)e.getSource()).getText().equals("RULES"))
			{
				changePanel("info");
			}
			else if(((JButton)e.getSource()).getText().equals("Settings"))
			{
				changePanel("settings");
			}
			else if(((JButton)e.getSource()).getText().equals("Single Player"))
			{
				changePanel("single player game");
				gS.changeTrack("game.mp3");
				gS.changeSound(settings.getSoundSlider().getValue() / 100.0);
				spGame.initGame();
				spPlay.initPlay(spGame);
				spPlay.repaint();
			}
			else if(((JButton)e.getSource()).getText().equals("Multi Player"))
			{
				changePanel("name selection");
			}
			else if(((JButton)e.getSource()).getText().equals("CLICK TO CONTINUE"))
			{
				changePanel("multi player game");
				gS.changeTrack("game.mp3");
				gS.changeSound(settings.getSoundSlider().getValue() / 100.0);
				mpGame.initGame();
				mpPlay.initPlay(spGame);
				mpPlay.repaint();
			}
			else if(((JButton)e.getSource()).getText().equals("GAME MENU"))
			{
				changePanel("pause");
			}
			else if(((JButton)e.getSource()).getText().equals("FORFEIT GAME"))
			{
				changePanel("main menu");
				gS.changeTrack("menu.mp3");
				gS.changeSound(settings.getSoundSlider().getValue() / 100.0);
				if(spGame.isActive())
				{
					spGame.initGame();
				}
				else if(mpGame.isActive())
				{
					mpGame.initGame();
				}
			}
			else if(((JButton)e.getSource()).getText().equals("INFO"))
			{
				changePanel("info");
			}
			else if(((JButton)e.getSource()).getText().equals("RESUME GAME"))
			{
				if(spGame.isActive2())
				{
					changePanel("single player game");
				}
				else if(mpGame.isActive2())
				{
					changePanel("multi player game");
				}
			}
		}
	}
	
	class ReturnMainListener implements ActionListener
	{
		public void actionPerformed(ActionEvent e)
		{
			if(spGame.getReturnMain())
			{
				changePanel("main menu");
				spGame.initGame();
				spPlay.initPlay(spGame);
				spPlay.repaint();
				gS.changeTrack("menu.mp3");
				gS.changeSound(settings.getSoundSlider().getValue() / 100.0);
			}
			else if(mpGame.getReturnMain())
			{
				changePanel("main menu");
				mpGame.initGame();
				mpPlay.initPlay(mpGame);
				mpPlay.repaint();
				gS.changeTrack("menu.mp3");
				gS.changeSound(settings.getSoundSlider().getValue() / 100.0);
			}
		}
	}
	
	class SoundChangeListener implements ChangeListener
	{
		public void stateChanged(ChangeEvent e)
		{
			gS.changeSound(settings.getSoundSlider().getValue() / 100.0);
		}
	}
	
	/**
	 * Changes the current panel.
	 * @param str the String parameter that invokes the panels' names.
	 */
	public void changePanel(String str)
	{
		cardL.show(cards, str);
	}
	
	//testing
	public static void main(String[] args)
	{
		FingerCoinFrame fr = new FingerCoinFrame();
		fr.setVisible(true);
		fr.setTitle("FingerCoin");
		fr.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
	}
}
