package controllerClasses;
import javafx.embed.swing.JFXPanel;
import javafx.scene.media.*;
import java.io.File;
/**
 * This class creates the sound in the background of the FingerCoin game.
 * @author Arda Yüksel
 * @version 08.05.2017
 */
public class GameSound {
	
	//properties
	private Media media;
	private MediaPlayer player;
	private JFXPanel threadHandler;
	
	/**
	 * Constructor
	 * @param song is the title of the song.
	 */
	public GameSound(String song){
		threadHandler = new JFXPanel();
		media = new Media(new File(song).toURI().toString());
		player = new MediaPlayer(media);
	}
	
	/**
	 * Changes the sound level.
	 * @param level is the given sound level.
	 */
	public void changeSound(double level){
		if( level == 0){
			player.setMute(true);
		}
		else{
			player.setVolume(level);
		}
	}
	
	/**
	 * Stops the music.
	 */
	public void stopMusic(){
		player.stop();
	}
	
	/**
	 * Starts the music.
	 */
	public void start(){
		player.setCycleCount(MediaPlayer.INDEFINITE);
		player.setAutoPlay(true);
		player.play();
	}
	
	/**
	 * Changes the current track.
	 * @param song the wanted track.
	 */
	public void changeTrack(String song){
		stopMusic();
		media = new Media(new File(song).toURI().toString());
		player = new MediaPlayer(media);
		start();
	}
}
