package viewClasses;
import javax.swing.*;
/**
 * This class is the pause menu of the Finger Coin game.
 */
public class PauseMenuPanel extends JPanel
{
   //TO DO
}