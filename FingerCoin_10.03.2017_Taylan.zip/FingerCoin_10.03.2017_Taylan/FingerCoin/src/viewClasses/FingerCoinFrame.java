package viewClasses;

import playground.*;
import controllerClasses.*;
import java.awt.*;
import java.awt.event.*;
import java.awt.image.*;
import javax.swing.*;
import javax.swing.event.*;
import javax.imageio.*;
import java.io.*;

/**
 * The total FingerCoinFrame!!
 * @author Süleyman Taylan Topaloğlu, Mustafa Bay
 * @version 07.05.2017
 */
public class FingerCoinFrame extends JFrame
{
	//properties
	private JPanel cards;
	private MainMenuPanel mainMenu;
	private SettingsPanel settings;
	private NameSelectionPanel nameSelect;
	private CreditsPanel credits;
	private InfoPanel info;
	private PauseMenuPanel pauseMenu;
	private CardLayout cardL;
	private BufferedImage background;
	private GamePanel spGame, mpGame;
	private PlayPanel spPlay, mpPlay;
	private GameSound gS;
	private int difficultyLevel;
	private int coinType;
	private ScorePanel scoreP;
	private String sCurrentLine;
	private BufferedReader br = null;
	private FileReader fr = null;
	private String sCurrentLines;
	private BufferedReader br1 = null;
	private FileReader fr1 = null;
	
	//constructor
	public FingerCoinFrame()
	{
		setSize(800, 1080);
		initComponents();
	}
	
	//methods
	/**
	 * Sets up the components for FingerCoin.
	 */
	public void initComponents() //TODO
	{
		mainMenu = new MainMenuPanel();
		mainMenu.setName("main menu");
		settings = new SettingsPanel();
		settings.setName("settings");
		nameSelect = new NameSelectionPanel();
		nameSelect.setName("name selection");
		credits = new CreditsPanel();
		info = new InfoPanel();
		pauseMenu = new PauseMenuPanel();
		
		//difficultyLevel = settings.getDifficulty();
		//coinType = settings.getCoinType();
		spGame = new GamePanel(difficultyLevel, 1, coinType);
		mpGame = new GamePanel(difficultyLevel, 2, coinType);
		spPlay = new PlayPanel(spGame, 1);
		mpPlay = new PlayPanel(mpGame, 2);
		settings.getSoundSlider().addChangeListener(new SoundChangeListener());
		gS = new GameSound("menu.mp3");
		gS.changeSound(settings.getSoundSlider().getValue() / 100.0);
		gS.start();
		try
		{
			background = ImageIO.read(new File("table.jpg"));
		}
		catch(IOException e){}
		
		//adding the panels
		cards = new JPanel(new CardLayout());
		cards.add(mainMenu, "main menu");
		cards.add(settings, "settings");
		cards.add(nameSelect, "name selection");
		cards.add(info, "info");
		cards.add(credits, "credits");
		cards.add(spPlay, "single player game");
		cards.add(mpPlay, "multi player game");
		cards.add(pauseMenu, "pause");
		
		//adding the necessary listeners
		for(JButton s: settings.getButtons())
		{
			s.addActionListener(new MenuChangeListener());
		}
		
		for(JButton s: settings.getDifficultyButtons())
		{
			s.addActionListener(new DiffListener());
		}
		
		for(JButton s: settings.getCoinButtons())
		{
			s.addActionListener(new CoinListener());
		}
		
		for(JButton s: mainMenu.getButtons())
		{
			s.addActionListener(new MenuChangeListener());
		}
		
		info.getButton().addActionListener(new MenuChangeListener());
		credits.getButton().addActionListener(new MenuChangeListener());
		spPlay.getScorePanel().getButton().addActionListener(new MenuChangeListener());
		mpPlay.getScorePanel().getButton().addActionListener(new MenuChangeListener());
		for(JButton s: pauseMenu.getButtons())
		{
			s.addActionListener(new MenuChangeListener());
		}
		
		for(JButton s: nameSelect.getButtons())
		{
			s.addActionListener(new MenuChangeListener());
		}
		
		//setting the card layout
		cardL = (CardLayout) cards.getLayout();
		cardL.show(cards, "main menu");
		add(cards);
	}
	
	class DiffListener implements ActionListener//TODO
	{
		/**
		 * Processes the action event.
		 * @param e the action event.
		 */
		public void actionPerformed(ActionEvent e)
		{
			if(((JButton) e.getSource()).getText().equals("Easy"))
			{
				spGame.initGame(0, coinType);
				mpGame.initGame(0, coinType);
			}
			
			else if(((JButton) e.getSource()).getText().equals("Medium"))
			{
				spGame.initGame(1, coinType);
				mpGame.initGame(1, coinType);
			}
			
			else if(((JButton) e.getSource()).getText().equals("Hard"))
			{
				spGame.initGame(2, coinType);
				mpGame.initGame(2, coinType);
			}
			
			else if(((JButton) e.getSource()).getText().equals("LECTURE"))
			{
				spGame.initGame(3, coinType);
				mpGame.initGame(3, coinType);
			}
			
			spPlay.initPlay(spGame);
			mpPlay.initPlay(mpGame);
			spPlay.repaint();
			mpPlay.repaint();
		}
	}
	
	class CoinListener implements ActionListener
	{
		/**
		 * Processes the action event.
		 * @param e the action event.
		 */
		public void actionPerformed(ActionEvent e)
		{
			if(settings.getCoinType() == 0)
			{
				spGame.initGame(difficultyLevel, 0);
				mpGame.initGame(difficultyLevel, 0);
			}
			else if(settings.getCoinType() == 1)
			{
				spGame.initGame(difficultyLevel, 1);
				mpGame.initGame(difficultyLevel, 1);
			}
			else if(settings.getCoinType() == 2)
			{
				spGame.initGame(difficultyLevel, 2);
				mpGame.initGame(difficultyLevel, 2);
			}
			spPlay.initPlay(spGame);
			mpPlay.initPlay(mpGame);
			spPlay.repaint();
			mpPlay.repaint();
			System.out.println(settings.getCoinType());
		}
	}
	
	class MenuChangeListener implements ActionListener 
	{
		/**
		 * Processes the action event.
		 * @param e the action event.
		 */
		public void actionPerformed(ActionEvent e) 
		{
			
			if(((JButton)e.getSource()).getText().equals("Back to main menu"))
			{
				changePanel("main menu");
			}
			else if(((JButton)e.getSource()).getText().equals("Close"))
			{
				if(spGame.isActive())
				{
					changePanel("single player game");
				}
				else if(mpGame.isActive())
				{
					changePanel("multi player game");
				}
				else
				{
					changePanel("settings");
				}
			}
			else if(((JButton)e.getSource()).getText().equals("Back to settings"))
			{
				changePanel("settings");
			}
			else if(((JButton)e.getSource()).getText().equals("CREDITS"))
			{
				changePanel("credits");
			}
			else if(((JButton)e.getSource()).getText().equals("RULES"))
			{
				changePanel("info");
				if(!spGame.isActive() || !mpGame.isActive())
				{
					
				}
			}
			else if(((JButton)e.getSource()).getText().equals("Settings"))
			{
				changePanel("settings");
			}
			else if(((JButton)e.getSource()).getText().equals("Single Player"))
			{
				changePanel("single player game");
				gS.changeTrack("game.mp3");
			}
			else if(((JButton)e.getSource()).getText().equals("Multi Player"))
			{
				changePanel("name selection");
			}
			else if(((JButton)e.getSource()).getText().equals("CLICK TO CONTINUE"))
			{
				changePanel("multi player game");
				gS.changeTrack("game.mp3");
			}
			else if(((JButton)e.getSource()).getText().equals("GAME MENU"))
			{
				changePanel("pause");
			}
			else if(((JButton)e.getSource()).getText().equals("FORFEIT GAME"))
			{
				changePanel("main menu");
				gS.changeTrack("menu.mp3");
				if(spGame.isActive())
				{
					spGame.initGame(difficultyLevel, coinType);
				}
				else if(mpGame.isActive())
				{
					mpGame.initGame(difficultyLevel, coinType);
				}
			}
			else if(((JButton)e.getSource()).getText().equals("INFO"))
			{
				changePanel("info");
			}
			else if(((JButton)e.getSource()).getText().equals("RESUME GAME"))
			{
				if(spGame.isActive())
				{
					changePanel("single player game");
				}
				else if(mpGame.isActive())
				{
					changePanel("multi player game");
				}
			}
		}
	}
	class SoundChangeListener implements ChangeListener
	{
		public void stateChanged(ChangeEvent e)
		{
			gS.changeSound(settings.getSoundSlider().getValue() / 100.0);
		}
	}
	/**
	 * Changes the current panel.
	 * @param str the String parameter that invokes the panels' names.
	 */
	public void changePanel(String str)
	{
		cardL.show(cards, str);
	}
	//testing
	public static void main(String[] args)
	{
		FingerCoinFrame fr = new FingerCoinFrame();
		fr.setVisible(true);
		fr.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
	}
}
