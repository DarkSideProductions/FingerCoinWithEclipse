package viewClasses;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.image.BufferedImage;
import java.io.*;
import javax.imageio.*;
import javax.swing.*;
/**
 * This class is the pause menu of the FingerCoin game.
 * @author Ceyhun Emre �zt�rk
 * @version 09.05.2017
 */
public class PauseMenuPanel extends JPanel {
	
   //properties
   private JLabel label;
   private JButton button1;
   private JButton button2;
   private JButton button3;
   private BufferedImage background;
   private JButton[] buttons;
   
   /**
    * Constructor
    */
   public PauseMenuPanel() {
      label = new JLabel("GAME MENU");
      button1 = new JButton("RESUME GAME");
      button2 = new JButton("FORFEIT GAME");
      button3 = new JButton("INFO");
      
      setLayout(null);
      setPreferredSize( new Dimension(800,1080));
      label.setHorizontalAlignment( JLabel.CENTER);
      label.setBounds( 290, 50, 220, 50);
      label.setFont( new Font("Arial", 1, 20));
      label.setBorder( BorderFactory.createLineBorder(Color.RED));
      button1.setBounds( 290, 250, 220, 50);
      button2.setBounds( 290, 350, 220, 50);
      button3.setBounds( 290, 450, 220, 50);

      button1.setContentAreaFilled(false);
      button2.setContentAreaFilled(false);
      button3.setContentAreaFilled(false);

      button1.setForeground(Color.RED);
      button2.setForeground(Color.RED);
      button3.setForeground(Color.RED);
      
      button1.setFont(new Font("Arial", 1, 13));
      button2.setFont(new Font("Arial", 1, 13));
      button3.setFont(new Font("Arial", 1, 13));

      try {
    	  background = ImageIO.read(new File("pause.jpg"));
      }
      catch(IOException e){}
      
      add(label);
      add(button1);
      add(button2);
      add(button3);
   }
   public void setButtons()
   {
   	buttons = new JButton[3];
   	buttons[0] = button1;
   	buttons[1] = button2;
   	buttons[2] = button3;
   	
   }
   public JButton[] getButtons()
   {
   	setButtons();
   	return buttons;
   }
   /**
    * Paints the panel.
    * @param g is the graphic instructions.
    */
   public void paintComponent(Graphics g) {
	   super.paintComponent(g);
	   g.drawImage(background, 0, 0, 800, 1200, null);
	   g.drawRect( 200, 0, 400, 600);
   }
   
   /**
    * This method is for test purposes.
    */
   public static void main(String[] args) {
	   JFrame fr = new JFrame();
	   fr.add(new PauseMenuPanel());
	   fr.setSize(800, 1080);
	   fr.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
	   fr.setVisible(true);
   }
}
