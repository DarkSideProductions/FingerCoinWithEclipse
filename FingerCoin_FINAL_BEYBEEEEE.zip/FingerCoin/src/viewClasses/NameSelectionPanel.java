package viewClasses;
import playground.*;
import java.awt.*;
import java.awt.event.*;
import java.awt.image.*;
import javax.swing.*;
import javax.imageio.*;
import java.io.*;

/**
 * This class creates the name selection window in the multiplayer mode of FingerCoin.
 * @author Süleyman Taylan Topaloğlu
 * @version 11.05.2017
 */
public class NameSelectionPanel extends JPanel 
{
	//properties
	private JLabel namep1, namep2;
	private JTextField p1, p2;
	private JButton clickToContinue, back;
	private BufferedImage background;
	private String name1, name2;
	private JButton[] buttons;
	private CheckingName key;
	private BufferedWriter bw = null;
	private FileWriter fw = null;
	private BufferedWriter bw1 = null;
	private FileWriter fw1 = null;
	
	//constructors
	public NameSelectionPanel()
	{
		namep1 = new JLabel("First User's Name:");
		namep2 = new JLabel("Second User's Name:");
		p1 = new JTextField();
		p2 = new JTextField();
		back = new JButton("Back to main menu");
		key = new CheckingName();
		p1.addKeyListener(key);
		p2.addKeyListener(key);
		clickToContinue = new JButton("CLICK TO CONTINUE");
		try
        {
        	background = ImageIO.read(new File("table.jpg"));
        }
      catch(IOException e){}
//		name1 = p1.getText();
//		name2 = p2.getText();
		System.out.println(p1.getText() + "////////" + p2.getText());
		System.out.println("////////");
		setLayout(null);
		namep1.setBounds(150, 300, 200, 50);
		namep1.setFont(new Font("Arial",Font.PLAIN,20));
		p1.setBounds(360, 310, 200, 30);
		namep2.setBounds(150, 550, 200, 50);
		namep2.setFont(new Font("Arial",Font.PLAIN,20));
		p2.setBounds(360, 560, 200, 30);
		back.setBounds(50, 50, 100, 30);
		clickToContinue.setBounds(250, 750, 300, 60);
		clickToContinue.setFont(new Font("Arial", Font.PLAIN, 25));
		clickToContinue.setContentAreaFilled(false);
		add(namep1);
		add(p1);
		add(namep2);
		add(p2);
		add(back);
		add(clickToContinue);
		
	}
//	/**
//	 * Gets the name of the first player.
//	 * @return the name of the first player.
//	 */
//	public String getName1()
//	{
//		return name1;
//	}
//	/**
//	 * Gets the name of the second player.
//	 * @return the name of the second player.
//	 */
//	public String getName2()
//	{
//		return name2;
//	}
	/**
     * Sets the buttons array of this panel.
     */
	public void setButtons()
    {
    	buttons = new JButton[2];
    	buttons[0] = back;
    	buttons[1] = clickToContinue;
    	
    }
    /**
     * Returns the buttons array.
     * @return the buttons array.
     */
    public JButton[] getButtons()
    {
    	setButtons();
    	return buttons;
    }
    /**
     * Gets the array of text fields.
     * @return the array of text fields.
     */
    public JTextField[] getNameFields()
	{
		JTextField[] res;
		res = new JTextField[2];
		res[0] = p1;
		res[1] = p2;
		return res;
	}
    
    private class CheckingName extends KeyAdapter
    {
		public void keyReleased( KeyEvent e)
		{
			System.out.println("x");
			try {
				fw = new FileWriter("name1.txt");
				bw = new BufferedWriter(fw);
				bw.write(p1.getText());
				bw.close();
			} catch (IOException a) {
				a.printStackTrace();
			}
			
			try {
				fw = new FileWriter("name2.txt");
				bw = new BufferedWriter(fw);
				bw.write(p2.getText());
				bw.close();
			} catch (IOException a) {
				a.printStackTrace();
			}
			name1 = p1.getText();
			name2 = p2.getText();
			System.out.println(name1);
			System.out.println(name2);
		}
	}
		
	//methods
	/**
	 * Paints the panel with the background image.
	 * @param g the Graphics reference.
	 */
	public void paintComponent(Graphics g)
	{
		super.paintComponent(g);
		g.drawImage(background, 0, 0, 800, 1200, null);
	}
	 
	 /**
	  * For testing purposes
	  */
	public static void main(String[] args)
	{
		JFrame fr = new JFrame();
		fr.add(new NameSelectionPanel());
		fr.setSize(800, 1080);
		fr.setVisible(true);
	}
}
