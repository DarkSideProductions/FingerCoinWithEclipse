package controllerClasses;
import javax.swing.*;
import viewClasses.*;
import playground.*;
import java.awt.*;
import java.awt.event.*;
import java.awt.*;
import java.awt.image.*;
import javax.imageio.*;

import java.io.*;
import java.util.ArrayList;
/**
 * The total playing panel of FingerCoin.
 * @author Mustafa Bay, Süleyman Taylan Topaloğlu
 * @version 10.05.2017
 */
public class PlayPanel extends JPanel 
{
	//properties
	private GamePanel gamePanel;
	private GameListener2 gl;
	private Timer timer;
	private int playerNumber;
	private ScorePanel scoreP;
	private String namep1, namep2;
	private BufferedImage background;
	
	//constructors
	public PlayPanel(GamePanel gp)
	{
		try
		{
			background = ImageIO.read(new File("gameGround.jpg"));
		}
		catch(IOException e){}
		this.gamePanel = gp;
		setPreferredSize(new Dimension(800, 1080));
		setLayout(null);
		playerNumber = 1;
		this.gamePanel.returnDirection().setBounds(400, 850, 200, 200);
		this.gamePanel.returnPower().setBounds(0, 800, 300, 200);
		add(this.gamePanel.returnDirection());
		add(this.gamePanel.returnPower());
		initPlay(this.gamePanel);
		
	}
	public PlayPanel(GamePanel gamePanel, String name1, String name2)
	{
		try
		{
			background = ImageIO.read(new File("gameGround.jpg"));
		}
		catch(IOException e){}
		this.gamePanel = gamePanel;
		setPreferredSize(new Dimension(800, 1080));
		setLayout(null);
		this.gamePanel.returnDirection().setBounds(400, 850, 200, 200);
		this.gamePanel.returnPower().setBounds(0, 800, 300, 200);
		namep1 = name1;
		namep2 = name2;
		playerNumber = 2;
		add(this.gamePanel.returnDirection());
		add(this.gamePanel.returnPower());
		initPlay(this.gamePanel);
		
	}
	
	//methods
	/**
	 * Initializes the playing panel.
	 * @param gamePanel the reference GamePanel.
	 */
	public void initPlay(GamePanel gamePanel)
	{
		gl = new GameListener2();
		this.timer = new Timer( 10, gl);
		timer.start();
		if(playerNumber == 1)
		{
			scoreP = new ScorePanel(this.gamePanel);
		}
		else
		{
			scoreP = new ScorePanel(this.gamePanel, namep1, namep2);
		}
		scoreP.setBounds(0, 0, 600, 60);
		this.gamePanel.setBounds(0, 60, 600, 700);
		add(scoreP);
		add(this.gamePanel);
	}
	/**
	 * Paints the panel with the background image.
	 * @param g the Graphics reference.
	 */
	public void paintComponent(Graphics g)
	{
		super.paintComponent(g);
		g.drawImage(background, 0, 0, this);
	}
	class GameListener2 implements ActionListener
	{
		public void actionPerformed( ActionEvent e)
		{
			if( playerNumber == 1)
			{
				scoreP.setTries(gamePanel.getField().getScore());
			}
			else
			{
				
				if(gamePanel.isPlayer1sTurn())
				{
					scoreP.setTriesP1(gamePanel.getField().getScore());
					scoreP.setTriesP2(0);
				}
				else
				{
					scoreP.setTriesP2(gamePanel.getField().getScore());
				}
			}
			scoreP.repaint();	
		}
    }
	/**
	 * Sets the names of the players in multi player mode.
	 * @param nm1 name of first player.
	 * @param nm2 name of second player.
	 */
	public void setNames(String nm1, String nm2)
	{ 
		namep1 = nm1;
		namep2 = nm2;
	}
	/**
	 * Gets the current score panel.
	 * @return the score panel.
	 */
	public ScorePanel getScorePanel()
	{
		return scoreP;
	}
	//testing
	/*public static void main(String[] args)
	{
		JFrame fr = new JFrame();
		fr.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		GamePanel x = new GamePanel( 0, 2, 1);
		//PlayPanel pp = new PlayPanel(x, 2);
		fr.setSize(800, 1080);
		fr.add(pp);
		fr.setVisible(true);
	}*/
}
