package viewClasses;

public class GoalkeeperVisual {

}
