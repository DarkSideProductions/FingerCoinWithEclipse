package viewClasses;

public class MainMenuPanel {

}
