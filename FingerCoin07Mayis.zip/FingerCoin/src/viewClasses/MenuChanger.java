/**
 * 
 */
package viewClasses;

import java.awt.CardLayout;
import javax.swing.*;
import java.awt.event.*;

/**
 * @author TAYLAN
 *
 */
public class MenuChanger extends JFrame
{
	
}