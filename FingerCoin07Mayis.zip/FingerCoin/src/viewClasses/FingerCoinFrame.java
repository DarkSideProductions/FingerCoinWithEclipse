package viewClasses;

import playground.*;
import java.awt.*;
import java.awt.event.*;
import java.awt.image.*;
import javax.swing.*;
import javax.swing.event.*;
import javax.imageio.*;
import java.io.*;

/**
 * @author TAYLAN
 */
public class FingerCoinFrame extends JFrame
{
	public static JPanel cards;
	private JPanel mainMenu, settings, nameSelect, credits, info, singleScore, multiScore, singlePlayer, multiPlayer, fieldPanel;
	public static CardLayout cardL;
	private BufferedImage background;
	public FingerCoinFrame()
	{
		setSize(800, 1080);
		initComponents();
	}
	public void initComponents()
	{
		mainMenu = new MainMenuPanel();
		mainMenu.setName("main menu");
		settings = new SettingsPanel();
		settings.setName("settings");
		nameSelect = new NameSelectionPanel();
		nameSelect.setName("name selection");
		//credits = new CreditsPanel();
		//info = new InfoPanel();
		singleScore = new SingleScorePanel();
		singleScore.setName("single score");
		multiScore = new MultiScorePanel();
		multiScore.setName("multi score");
		//singlePlayer = new GamePanel();
		//multiPlayer = new GamePanel();
		//fieldPanel = new 
		try
		{
			background = ImageIO.read(new File("table.jpg"));
		}
		catch(IOException e){}
		
		paintBackground();
		cards = new JPanel(new CardLayout());
		cards.add(mainMenu, "main menu");
		cards.add(settings, "settings");
		cards.add(nameSelect, "name selection");
		cards.add(singleScore, "single score");
		cards.add(multiScore, "multi score");
		
		cardL = (CardLayout) cards.getLayout();
		cardL.show(cards, "main menu");
		add(cards);
	}
	public void paintBackground()
	{
		Graphics g = background.getGraphics();
		g.drawRect(0, 0, 800, 1080);
	}
	public static void changePanel(String str)
	{
		cardL.show(cards, str);
	}
	
	public static void main(String[] args)
	{
		FingerCoinFrame fr = new FingerCoinFrame();
		fr.setVisible(true);
		fr.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
	}
}
