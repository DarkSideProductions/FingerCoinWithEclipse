/**
 * 
 */
package viewClasses;
import javax.swing.*;
import java.awt.event.*;
/**
 * @author TAYLAN
 *
 */
public class CardTest {

	/**
	 * @param args
	 */
	public static void main(String[] args) 
	{
		JFrame fr;
		fr = new JFrame();
		JPanel p1 = new JPanel();
		JButton b1 = new JButton("1");
		p1.add(b1);
		fr.add(p1);
		fr.setSize(500,700);
		//MenuChanger mC = new MenuChanger(p1);
		/*JPanel p2 = new JPanel();
		JButton b2 = new JButton("2");
		p2.add(b2);
		fr.add(p2);
		mC.addCards(p2);
		mC.goPrev(p2);*/
		
		fr.setVisible(true);
		fr.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);

	}
	class Lis implements ActionListener
	{
		public void actionPerformed(ActionEvent e)
		{
			
		}
	}
}
